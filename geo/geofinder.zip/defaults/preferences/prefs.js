pref("extensions.geofinder.boolpref", false);
pref("extensions.geofinder.intpref", 0);
pref("extensions.geofinder.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.vamshi4001@gmail.com.description", "chrome://geofinder/locale/overlay.properties");
